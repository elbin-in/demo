import React, { useContext, useState } from 'react'
import { Container, Row } from 'reactstrap';
import Directcontext from '../Contextapi/Directcontext';
import { Button } from 'reactstrap';
import { AiOutlineHeart } from "react-icons/ai";
export default function SearchPage(props) {
  const user = useContext(Directcontext)
  const [activeIndex, updateActiveInd] = useState(9)
  document.title = `Home Page`;
  const clickIndex = (event) => {
    updateActiveInd(activeIndex + 9)
  }
  return (
    <div><h2 className="h2-title">Property for sales</h2>
      <Container>
        <Row>
          {user.data && user.data.length > 0 ?
            user.data.map((item, index) =>
              activeIndex > index ?
                <div className="search-single-item" onClick={() => user.clickProduct(item)}>
                  <div className="icon-heart"><AiOutlineHeart /> </div>
                  {item && item.Images.length > 0 ? item.Images.map((img, imgindex) => imgindex === 0 && img.url ? <div className="bg-img" style={{ 'background-image': `url(${img.url})` }} ></div> : null) : <div className="bg-img-empty">Image Not Available</div>}
                  <div className="name">{item.Title}</div>
                  <div className="desc">{item.Building_Type}</div>
                  <div className="prize">{user.numberWithCommas(item.Price) + ' £'}</div>
                </div>
                : null
            ) : null}
          {activeIndex === 9 ? <Button className="load-more-btn" onClick={() => clickIndex()}>Load More</Button> : null}
          {activeIndex === 18 ? <Button className="load-more-btn" onClick={() => clickIndex()}>Load More</Button> : null}
          {activeIndex === 27 ? <Button className="load-more-btn" onClick={() => clickIndex()}>Load More</Button> : null}
          {activeIndex === 36 ? <Button className="load-more-btn" onClick={() => clickIndex()}>Load More</Button> : null}
          {activeIndex === 54 ? null : null}
        </Row>
      </Container>
    </div>
  )
}