import React, { useEffect, useContext, useState } from 'react'
import Directcontext from '../Contextapi/Directcontext';
import { Container, Row, Col } from 'reactstrap';
import { Button } from 'reactstrap';
import { AiOutlineHeart, AiOutlineShareAlt, AiFillHeart } from "react-icons/ai";
import GoogleMapReact from 'google-map-react';
export default function DetailPage(props) {
    const AnyReactComponent = ({ text }) => <div>{text}</div>;
    const user = useContext(Directcontext)
    const [activeImg, updateActiveimg] = useState('')
    const [heart, updateHeart] = useState(false)
    document.title = user.detail && user.detail.Title ? user.detail.Title : 'N/A';
    useEffect(() => {
        window.scrollTo(0, 0)
        updateActiveimg(user.detail && user.detail.Images && user.detail.Images.length > 0 ? user.detail.Images[0].url : '')
    }, []);
    const clickImage = (event) => {
        updateActiveimg(event)
    }
    const clickHeart = (event) => {
        updateHeart(event)
    }
    return (
        <Container>
            <Row>
                <Col sm="7">
                    {activeImg ? <div className="full-img" style={{'background-image': `url(${activeImg})`}}></div> : <div className="big-img-empty">Image Not Available</div>}
                    <div className="gallery"><div className="scrolls">{user.detail && user.detail.Images.length > 0 ? user.detail.Images.map((img, imgindex) => <div onClick={() => clickImage(img.url)} className="list-img" style={{'background-image': `url(${img.url})`}}></div>) : null}</div></div>
                </Col>
                <Col sm="5">
                <h5 className="h5-t">
    <div className="icons"> <AiOutlineShareAlt/> {heart ? <AiFillHeart onClick={() => clickHeart(false)}/> : <AiOutlineHeart onClick={() => clickHeart(true)}/>}</div>
                </h5>
                    <div className="detail-blk">
                        <div><span className="prize">{user.detail ? '£'+user.numberWithCommas(user.detail.Price)  : 'N/A'}</span>
                            <span className="rooms">{user.detail.Bedrooms ? user.detail.Bedrooms === 1 ? user.detail.Bedrooms + ' bed' : user.detail.Bedrooms + ' beds' : 'N/A'}</span>
                            <span className="sqm">{user.detail ? user.detail.Floor_Area + ' Sqm' : 'N/A'}</span>
                        </div>
                        <div className="title">{user.detail ? user.detail.Title : 'N/A'}</div>
                        <div className="pl-con">Please contact us</div>

                    </div>
                    <Button className="con-btn" color="primary">Contact Agent</Button>
                    <div className="facts">
                        <h5 className="h5-t">FACTS & FEATURES</h5>
                        <table>
                            <tr>
                                <td><b>Neighbourhood:</b></td>
                                <td>{user.detail && user.detail.neighbourhood ? user.detail.neighbourhood : 'N/A'}</td>
                            </tr>
                            <tr>
                                <td><b>Price Per Sqm:</b></td>
                                <td>{user.detail && user.detail.Price_Per_Sqm ? '£'+user.numberWithCommas(user.detail.Price_Per_Sqm) : 'N/A'}</td>
                            </tr>
                            <tr>
                                <td><b>Brochure:</b></td>
                                <td>
                                    <a href={user.detail && user.detail.Brochure.length > 0 ? user.detail.Brochure[0].url : '#'} target="_blank">{user.detail && user.detail.Brochure.length > 0 ? user.detail.Brochure[0].name : 'N/A'}</a>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Floor_Plans:</b></td>
                                <td>
                                    {/* {user.detail ? user.detail.Neighbourhood : 'N/A'} */}
                                </td>
                            </tr>
                        </table>
                        <div className="desc1" dangerouslySetInnerHTML={{ __html: user.detail ? user.detail.Description : 'N/A' }}>
                        </div>
                        <div className="contact">
                            <div className="img" style={{'background-image': `url(${user.detail ? user.detail.Negotiator.Image.url : ''})`}} ></div>
    <div className="name">{user.detail ? user.detail.Negotiator.Name : 'N/A'}</div>
    <div className="desgination">{user.detail ? user.detail.Negotiator.Designation : 'N/A'}</div>
    <div className="contact-detail">
        <span className="phone">{user.detail ? '+'+user.detail.Negotiator.Phone : 'N/A'}</span>
        <span className="email"><a class="mailto" href={'mailto:http://'+user.detail ? user.detail.Negotiator.Email : "#"}>Email</a> </span>
    </div>
                        </div>
                        <div style={{ height: '100px', width: '100%' }}>
                        <GoogleMapReact
          bootstrapURLKeys={{ key: '' }}
          defaultCenter={{
            lat: user.detail && user.detail.Latitude ? user.detail.Latitude : '',
            lng: user.detail && user.detail.Longitude ? user.detail.Longitude : ''
          }}
          defaultZoom={11}
        >
          <AnyReactComponent
            lat={user.detail && user.detail.Latitude ? user.detail.Latitude : ''}
            lng={user.detail && user.detail.Longitude ? user.detail.Longitude : ''}
            text="My Marker"
          />
        </GoogleMapReact>
        </div>
                    </div>
                </Col>
            </Row>
        </Container>
    )
}