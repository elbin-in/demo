import React from 'react'

const Directcontext = React.createContext()

export const DirectProvider = Directcontext.Provider
export const DirectConsumer = Directcontext.Consumer

export default Directcontext