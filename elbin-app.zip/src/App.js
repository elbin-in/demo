import React from 'react';
import './App.css';
import { BrowserRouter, Switch, Route } from 'react-router-dom'
import { createBrowserHistory } from 'history';
import Main from './Layout/Main.jsx';
import DetailPage from './Views/DetailPage.jsx';
import SearchPage from './Views/SearchPage.jsx';
const browserHistory = createBrowserHistory();
function App() {
  return (
    <div className="App">
      <BrowserRouter history={browserHistory}>
        <Switch>
          <Main>
            <Route type="home" exact path='/' component={SearchPage} />
            <Route type="detail" exact path='/:slug' component={DetailPage} />
          </Main>
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
