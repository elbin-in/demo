import React, { useState, useEffect } from 'react';
import { DirectProvider } from '../Contextapi/Directcontext.js'
import DetailPage from '../Views/DetailPage.jsx';
import SearchPage from '../Views/SearchPage.jsx';
import kloader from "../Assets/loader.gif";
import axios from 'axios';
import { useHistory } from "react-router-dom";
function numberWithCommas(x) {
  if (x === 0) {
    return '';
  } else {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
}
function Main(props) {
  const history = useHistory();
  const [data, updateData] = useState([])
  const [loader, updateLoader] = useState(false)
  const [detail, updateDetail] = useState([])
  useEffect(() => {
    updateLoader(true)
    axios.get(`https://carolineolds-strapi-dev.q.starberry.com/properties?_limit=50`)
      .then(res => {
        const data = res.data;
        updateData(data)
        updateLoader(false)
      })
  }, []);
  const clickProduct = (value) => {
    updateDetail(value)
    let path = value.Slug;
    history.push(path);
  }
  return (
    <DirectProvider
      value={{
        data, clickProduct,
        detail, numberWithCommas
      }}
    >
      {loader ?
        <div className='loader'><img src={kloader} /></div>
        : null}
      <div className="layout">
        <div className="header">Header Section</div>
        <div className="content-blk">
          {
            props.location.pathname === '/' ?
              <SearchPage />
              :
              <DetailPage />
          }
        </div>
        <div className="footer">Footer Section</div>
      </div>
    </DirectProvider>
  );
}
export default Main;