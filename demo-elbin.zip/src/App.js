import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import 'date-fns';
import Grid from '@material-ui/core/Grid';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from '@material-ui/pickers';
import moment from 'moment'
import Paper from '@material-ui/core/Paper';
import IconButton from '@material-ui/core/IconButton';
import AddIcon from '@material-ui/icons/Add';
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/Delete';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));
function tochangedateformat(value) {
  if (value === null || value === undefined || value === '') {
    return value
  }
  else {
    var dateParts = value.split("/");

    // month is 0-based, that's why we need dataParts[1] - 1
    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]);
    return dateObject
  }
}
function App() {
  const classes = useStyles();
  const [selectedDate, setSelectedDate] = useState(null);
  const [taskname, updatetaskname] = useState('')
  const [user, updateusername] = useState(0)
  const [task, updatetask] = useState(false)
  const [data, updateData] = useState([])
  const editTask = (event, id) => {
    var editdata = data[id]
    var date = editdata.date;
    var time = editdata.time;
    var momentObj = moment(date + time, 'YYYY-MM-DDLT');
    console.log(tochangedateformat(date))
    // var dateTime = momentObj.format('YYYY-MM-DDTHH:mm:s');
    setSelectedDate(momentObj)

    updatetask(true)
    updatetaskname(editdata.taskname)
    updateusername(editdata.user)
  }
  const deleteTask = (event, id) => {
    data.splice(id, 1)
    updateData([...data])
  }
  const addtask = (event) => {
    updatetask(true)
  }
  const saveData = (event) => {
    debugger
    var now = selectedDate
    var date = now.toLocaleDateString();
    var time = now.toLocaleTimeString();
    let obj = {
      rowid: data.length,
      taskname: taskname,
      date: date,
      time: time,
      user: user
    }
    updateData([...data, obj])
    setSelectedDate(null)
    updatetask(false)
    updatetaskname('')
    updateusername(0)

  }
  const canceltask = (event) => {
    setSelectedDate(null)
    updatetask(false)
    updatetaskname('')
    updateusername(0)
  }
  const handleDateChange = (date) => {
    setSelectedDate(date);
    console.log(date)
  };
  const handleChange = (event) => {
    if (event.target.name === 'taskname') {
      updatetaskname(event.target.value)

    }
    if (event.target.name === 'user') {
      updateusername(event.target.value)
    }

  };
  return (
    <div className="App">
      <TableContainer component={Paper}>
        {!task ? <div className="task-blk">Add Task <IconButton onClick={addtask} aria-label="Add">
          <AddIcon />
        </IconButton></div> : task ?
            <form className="form-blk"
            >

              <FormControl
              >
                <TextField
                  fullWidth
                  value={taskname}
                  onChange={handleChange}
                  autoComplete='off'
                  name="taskname"
                  label='Task Description'
                />

              </FormControl>
              <FormControl
              >
                <MuiPickersUtilsProvider utils={DateFnsUtils}>

                  <KeyboardDatePicker
                    disableToolbar
                    variant="inline"
                    format="MM/dd/yyyy"
                    margin="normal"
                    id="date-picker-inline"
                    label="Date"
                    value={selectedDate}
                    onChange={handleDateChange}
                    autoOk={true}
                    KeyboardButtonProps={{
                      'aria-label': 'change date',
                    }}
                  />
                  <KeyboardTimePicker
                    disableToolbar
                    variant="inline"
                    autoOk={true}
                    margin="normal"
                    id="time-picker"
                    label="Time"
                    value={selectedDate}
                    onChange={handleDateChange}
                    KeyboardButtonProps={{
                      'aria-label': 'change time',
                    }}
                  />
                </MuiPickersUtilsProvider>
              </FormControl>
              <FormControl className={classes.formControl}>
                <InputLabel id="demo-simple-select-label">Assign User</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={user}
                  onChange={handleChange}
                  name='user'
                  autoWidth={true}
                >
                  <MenuItem value={1}>Elbin</MenuItem>
                  <MenuItem value={2}>Ruban</MenuItem>
                  <MenuItem value={3}>Prabhu</MenuItem>
                </Select>
              </FormControl>
              <div>
                <Button onClick={saveData} variant="contained" color="primary">
                  Save
</Button>
                <Button onClick={canceltask} variant="outlined" color="primary">
                  Cancel
</Button>
              </div>
            </form> : ''}
        <Table aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Task Name</TableCell>
              <TableCell >Date</TableCell>
              <TableCell >Time</TableCell>
              <TableCell>User Name</TableCell>
              <TableCell >Actions</TableCell>



            </TableRow>
          </TableHead>
          <TableBody>
            {data && data.length > 0 ? data.map((row, index) => (<TableRow>
              <TableCell >{row.taskname}</TableCell>
              <TableCell >{row.date}</TableCell>
              <TableCell >{row.time}</TableCell>
              <TableCell >{row.user === 1 ? 'Elbin' : row.user === 2 ? 'Ruban' : row.user === 3 ? 'Prabhu' : ''}</TableCell>
              <TableCell>
                <IconButton onClick={(event) => { editTask(event, index) }} aria-label="Edit">
                  <EditIcon />
                </IconButton>
                <IconButton onClick={(event) => { deleteTask(event, index) }} aria-label="delete">
                  <DeleteIcon />
                </IconButton>

              </TableCell>
            </TableRow>
            ))
              : <TableRow><TableCell colSpan={5}><div className="center-align">No records</div></TableCell></TableRow>}
          </TableBody>
        </Table>
      </TableContainer>

    </div>
  );
}

export default App;
